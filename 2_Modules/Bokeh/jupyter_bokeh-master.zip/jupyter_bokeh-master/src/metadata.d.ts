export declare const name: string
export declare const version: string
