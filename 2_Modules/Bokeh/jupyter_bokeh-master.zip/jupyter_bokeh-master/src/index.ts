import {extension} from "./plugin"
export default extension

export * from "./widgets"
